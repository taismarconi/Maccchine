var searchData=
[
  ['punteggio',['punteggio',['../structscore__t.html#af9cab55b503e0fb7c0e5ac791266bc52',1,'score_t']]]
];
