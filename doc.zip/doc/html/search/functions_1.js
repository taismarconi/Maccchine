var searchData=
[
  ['check_5fcollisione',['check_collisione',['../function_8h.html#a37564a82e85505ac1518d4b22f21041e',1,'check_collisione(car_t &amp;, enemy_t *&amp;, bool &amp;, ALLEGRO_BITMAP *):&#160;move_car.cpp'],['../move__car_8cpp.html#a2bc108c0e9911d1b914610d7e03c9ce4',1,'check_collisione(car_t &amp;c, enemy_t *&amp;ene, bool &amp;collisione, ALLEGRO_BITMAP *boom):&#160;move_car.cpp']]]
];
