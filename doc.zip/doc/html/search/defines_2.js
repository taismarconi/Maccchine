var searchData=
[
  ['scorebar_5fsize',['SCOREBAR_SIZE',['../data_8h.html#a0c5f809754575cdaffee27100a59a6a0',1,'data.h']]],
  ['screen_5fh',['SCREEN_H',['../data_8h.html#a27cddfd509d28b4b2b0b44c093fac090',1,'data.h']]],
  ['screen_5fw',['SCREEN_W',['../data_8h.html#a9b6bc9242882d1e758e06ed751a2e8ec',1,'data.h']]]
];
