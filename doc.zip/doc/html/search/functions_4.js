var searchData=
[
  ['replay',['replay',['../function_8h.html#a14d6c711b147eeb4a1ec213db9f4b0ed',1,'replay(car_t &amp;, enemy_t *&amp;, score_t &amp;):&#160;start_finish.cpp'],['../start__finish_8cpp.html#ac98f00120b9417a7909c6af14cf446fa',1,'replay(car_t &amp;c, enemy_t *&amp;ene, score_t &amp;score):&#160;start_finish.cpp']]]
];
