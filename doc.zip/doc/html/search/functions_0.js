var searchData=
[
  ['break_5fgame',['break_game',['../function_8h.html#a1758b74691046a62adcefa1a98b7b7ef',1,'break_game(ALLEGRO_EVENT_QUEUE *, bool &amp;):&#160;start_finish.cpp'],['../start__finish_8cpp.html#a58af6b6998b2d7143940a3203dffeb70',1,'break_game(ALLEGRO_EVENT_QUEUE *event_queue, bool &amp;pausa):&#160;start_finish.cpp']]]
];
