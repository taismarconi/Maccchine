var searchData=
[
  ['imm',['imm',['../structenemy__t.html#acdef8bf0c2ce58c33fee866037e792b9',1,'enemy_t::imm()'],['../structcar__t.html#af5df6a00f7c8d72dd6ccda51612990be',1,'car_t::imm()']]]
];
