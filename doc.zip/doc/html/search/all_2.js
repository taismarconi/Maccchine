var searchData=
[
  ['data_2eh',['data.h',['../data_8h.html',1,'']]],
  ['doexit',['doexit',['../game__core_8cpp.html#aa48e7762f330111ade0894c6df93f1b6',1,'doexit():&#160;start_finish.cpp'],['../start__finish_8cpp.html#aa48e7762f330111ade0894c6df93f1b6',1,'doexit():&#160;start_finish.cpp']]]
];
