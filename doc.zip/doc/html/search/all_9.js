var searchData=
[
  ['nome_5ffile',['nome_file',['../data_8h.html#a07e273e0d96f70718f29c856dfa1980d',1,'data.h']]],
  ['num_5fenemies',['num_enemies',['../game__core_8cpp.html#ac5e676ab87b26df3ec0da81f0cc481cc',1,'num_enemies():&#160;start_finish.cpp'],['../move__car_8cpp.html#ac5e676ab87b26df3ec0da81f0cc481cc',1,'num_enemies():&#160;start_finish.cpp'],['../move__road_8cpp.html#ac5e676ab87b26df3ec0da81f0cc481cc',1,'num_enemies():&#160;start_finish.cpp'],['../start__finish_8cpp.html#ac5e676ab87b26df3ec0da81f0cc481cc',1,'num_enemies():&#160;start_finish.cpp']]]
];
