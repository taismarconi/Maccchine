var searchData=
[
  ['game_5fcore_2ecpp',['game_core.cpp',['../game__core_8cpp.html',1,'']]],
  ['game_5fover',['game_over',['../function_8h.html#a6a8fc8076167ecf18316d7bf415ba943',1,'game_over(ALLEGRO_EVENT_QUEUE *, car_t &amp;, enemy_t *&amp;, bool &amp;, ALLEGRO_BITMAP *):&#160;start_finish.cpp'],['../start__finish_8cpp.html#a2065367e24ed38061ead377bee178b87',1,'game_over(ALLEGRO_EVENT_QUEUE *event_queue, car_t &amp;c, enemy_t *&amp;ene, bool &amp;collisione, ALLEGRO_BITMAP *boom):&#160;start_finish.cpp']]],
  ['gestione_5fmenu',['gestione_menu',['../function_8h.html#ad4d9a8a33b4281e10ea44baad39a46a8',1,'gestione_menu(ALLEGRO_DISPLAY *):&#160;start_finish.cpp'],['../start__finish_8cpp.html#a0294714578bfb30cbd2d7743a65e068d',1,'gestione_menu(ALLEGRO_DISPLAY *display):&#160;start_finish.cpp']]]
];
