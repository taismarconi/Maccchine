var indexSectionsWithContent =
{
  0: "bcdefgikmnprsxy",
  1: "ces",
  2: "defgmrs",
  3: "bcgmr",
  4: "dfikmnprsxy",
  5: "m",
  6: "k",
  7: "ces",
  8: "bm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "File",
  3: "Funzioni",
  4: "Variabili",
  5: "Tipi enumerati (enum)",
  6: "Valori del tipo enumerato",
  7: "Definizioni",
  8: "Pagine"
};

