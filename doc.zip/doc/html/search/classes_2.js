var searchData=
[
  ['score_5ft',['score_t',['../structscore__t.html',1,'']]]
];
