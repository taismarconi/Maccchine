var searchData=
[
  ['benvenuto_20nella_20documentazione_20di_20maccchine_20_5cn',['Benvenuto nella documentazione di Maccchine \n',['../index.html',1,'']]]
];
