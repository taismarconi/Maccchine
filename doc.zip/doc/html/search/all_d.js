var searchData=
[
  ['x',['x',['../structenemy__t.html#ad5e881030125f0d84e98ece8cef1a93f',1,'enemy_t::x()'],['../structcar__t.html#abf77acc53fd55d01395a838d8ac6f0ad',1,'car_t::x()']]]
];
