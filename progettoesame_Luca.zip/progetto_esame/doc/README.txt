Flappy birds è un'implementazione della famosa app per telefono, lo scopo del gioco è rimanere in vita il più possibile cercando di 
non toccare il terreno o i tubi.

Autore: Luca Reggiani

Per navigare la documentazione del programma, aprire con un browser il file
"file:///home/luca/Scrivania/progetto_esame/doc/html/index.html"
oppure si apra la pagina "index.html" nella directory Scrivania/progetto_esame/doc/html.

GUIDA ALL'INSTALLAZIONE:

Il programma ha bisogno della libreria grafica Allegro5 per funzionare. Può essere
installata in 2 modi:

1. Utilizzando i pacchetti (Consigliato)
Apri il terminale, e digita il seguente comando:

sudo apt-get install liballegro5.0 liballegro5-dev liballegro-ttf5-dev liballegro-image5-dev

2. Utilzzando i file contenuti nella cartella lib
Prendere i diritti di root. Quindi:
-creare una cartella di nome "allegro5" nella directory "/usr/include". Quindi,
 copiare i file contenuti nella cartella "lib/include" dell'archivio nella cartella
 appena creata.
-creare una cartella di nome "allegro5" nella directory "/usr/include/x86_64-linux-gnu".
 Quindi, copiare i file contenuti nella cartella "lib/x86_64-linux-gnu" dell'archivio nella cartella
 appena creata.
-copiare i file contenuti nella cartella "lib/so" dell'archivio nella cartella
 "usr/lib".
 
GUIDA AL GIOCO:
 
Per giocare basta premere la freccia su o la barra spaziatrice, saltando verso l'alto per evitare i tubi in avvicinamento. per mettere in pausa il gioco basta premere invio durante la partita e per riprenderlo basta premerlo nuovamente. quando il personaggio perde è possibile premere il pulsante invio per ricominciare il gioco.

COME SCOMPATTARE IL PROGETTO COMPRESSO:

tar zxvf progetto_esame.tar.gz progetto_esame
