var searchData=
[
  ['pause',['pause',['../structSfondo.html#ae621957d9f5b3427ec2b48c1e37c2e55',1,'Sfondo']]],
  ['pavimento',['pavimento',['../structSfondo.html#a81c4305f69f4a18fa49d49394c1e7d40',1,'Sfondo']]],
  ['posx',['posX',['../structpersonaggio.html#a23553d996719a9ffaf96ca4a5bced5db',1,'personaggio']]],
  ['posx1',['posX1',['../structTubi.html#a107e1dd8ae4dbd7d4e6bff2ca4ee7602',1,'Tubi']]],
  ['posy',['posY',['../structpersonaggio.html#a31dd36f559ff8243aa0e3c9c47f39a03',1,'personaggio']]],
  ['posy1',['posY1',['../structTubi.html#a85bb973dc95dbbf020fff6adcec2bcd0',1,'Tubi']]],
  ['posy2',['posY2',['../structTubi.html#a9594749ccd0037bb7c026a814b6cbd1f',1,'Tubi']]]
];
