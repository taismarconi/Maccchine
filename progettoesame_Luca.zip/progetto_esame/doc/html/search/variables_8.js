var searchData=
[
  ['velocity',['velocity',['../structTubi.html#ad8d3a09fe90359b44a7c0092066ab5e5',1,'Tubi::velocity()'],['../structpersonaggio.html#a9ce321bfe1fbcde53391f32f8d7802cb',1,'personaggio::velocity()']]]
];
