var searchData=
[
  ['screen_5fh',['SCREEN_H',['../strutt__dati_8h.html#a42c075b5e54349391d38c5d53c4eddde',1,'strutt_dati.h']]],
  ['screen_5fw',['SCREEN_W',['../strutt__dati_8h.html#afca0db9c0e472d6c9aefd3022751d0ba',1,'strutt_dati.h']]],
  ['start',['start',['../structSfondo.html#ae91b4f0307170ca21f930625e019e5f6',1,'Sfondo']]]
];
