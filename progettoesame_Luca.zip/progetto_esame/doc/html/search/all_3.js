var searchData=
[
  ['file_2etxt',['file.txt',['../file_8txt.html',1,'']]],
  ['fine',['fine',['../strutt__dati_8h.html#adc6e5733fc3c22f0a7b2914188c49c90a1aeb85029f9ac98550b4da8729f91f3e',1,'strutt_dati.h']]],
  ['flappy_5fbirds2_2ecc',['flappy_birds2.cc',['../flappy__birds2_8cc.html',1,'']]],
  ['fps',['FPS',['../strutt__dati_8h.html#a9d399528f424abf9c67546aad6785e33',1,'strutt_dati.h']]],
  ['fuori_5fschermo',['fuori_schermo',['../structTubi.html#ab5fcbb9734f187070baf948ef40dd6d1',1,'Tubi']]]
];
