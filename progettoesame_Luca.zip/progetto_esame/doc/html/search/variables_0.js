var searchData=
[
  ['conta',['conta',['../structpersonaggio.html#aca23423ba7cfd9bf5452650611243152',1,'personaggio']]]
];
