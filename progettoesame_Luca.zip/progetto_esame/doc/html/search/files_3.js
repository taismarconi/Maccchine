var searchData=
[
  ['strutt_5fdati_2eh',['strutt_dati.h',['../strutt__dati_8h.html',1,'']]]
];
