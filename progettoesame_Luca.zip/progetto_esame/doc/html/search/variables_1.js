var searchData=
[
  ['fps',['FPS',['../strutt__dati_8h.html#a9d399528f424abf9c67546aad6785e33',1,'strutt_dati.h']]],
  ['fuori_5fschermo',['fuori_schermo',['../structTubi.html#ab5fcbb9734f187070baf948ef40dd6d1',1,'Tubi']]]
];
