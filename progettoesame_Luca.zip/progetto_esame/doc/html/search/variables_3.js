var searchData=
[
  ['inizio',['INIZIO',['../strutt__dati_8h.html#a11319a86f0ceb85619a2d84fe0e8db91',1,'strutt_dati.h']]]
];
