var searchData=
[
  ['inizializzazioni_2ecc',['inizializzazioni.cc',['../inizializzazioni_8cc.html',1,'']]],
  ['inizializzazioni_2eh',['inizializzazioni.h',['../inizializzazioni_8h.html',1,'']]]
];
