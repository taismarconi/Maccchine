var searchData=
[
  ['in_5fcorso',['in_corso',['../strutt__dati_8h.html#adc6e5733fc3c22f0a7b2914188c49c90a92b29085bc9a5603c7df8b35aaf5c651',1,'strutt_dati.h']]],
  ['inizio',['inizio',['../strutt__dati_8h.html#adc6e5733fc3c22f0a7b2914188c49c90a5af3ce25d0408be781b0ecac5365ea80',1,'strutt_dati.h']]]
];
