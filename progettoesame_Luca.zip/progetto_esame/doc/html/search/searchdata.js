var indexSectionsWithContent =
{
  0: "acdfgikmpstv",
  1: "pst",
  2: "afis",
  3: "acim",
  4: "cfgimpstv",
  5: "ms",
  6: "fikp",
  7: "d",
  8: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "File",
  3: "Funzioni",
  4: "Variabili",
  5: "Tipi enumerati (enum)",
  6: "Valori del tipo enumerato",
  7: "Definizioni",
  8: "Pagine"
};

