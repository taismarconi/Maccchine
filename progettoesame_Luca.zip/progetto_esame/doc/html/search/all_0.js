var searchData=
[
  ['aggiorna_5fgioco',['aggiorna_gioco',['../aggiornamenti_8cc.html#a018338011cf472fd8bfc8a3948be478f',1,'aggiorna_gioco(Sfondo &amp;background, state &amp;stato, personaggio &amp;player, float calcolo, Tubi tubo[], int &amp;primoTubo, int &amp;tub_conta, int &amp;punteggio, float &amp;incrementoVelocita, bool &amp;inc, ALLEGRO_FONT *scritta[], int &amp;record):&#160;aggiornamenti.cc'],['../aggiornamenti_8h.html#a018338011cf472fd8bfc8a3948be478f',1,'aggiorna_gioco(Sfondo &amp;background, state &amp;stato, personaggio &amp;player, float calcolo, Tubi tubo[], int &amp;primoTubo, int &amp;tub_conta, int &amp;punteggio, float &amp;incrementoVelocita, bool &amp;inc, ALLEGRO_FONT *scritta[], int &amp;record):&#160;aggiornamenti.cc']]],
  ['aggiornamenti_2ecc',['aggiornamenti.cc',['../aggiornamenti_8cc.html',1,'']]],
  ['aggiornamenti_2eh',['aggiornamenti.h',['../aggiornamenti_8h.html',1,'']]],
  ['aggiornaplayer',['AggiornaPlayer',['../aggiornamenti_8cc.html#a5d6d42799fd6ffea8ac8bbf6a0f4a086',1,'aggiornamenti.cc']]],
  ['aggiornasfondo',['AggiornaSfondo',['../aggiornamenti_8cc.html#a15b23d77fc0ab280f2b5e18f3c4bc7eb',1,'aggiornamenti.cc']]],
  ['aggiornastato',['AggiornaStato',['../aggiornamenti_8cc.html#a4362229d6e6cc337dcd63f14e8bf2b1d',1,'aggiornamenti.cc']]],
  ['aggiornatubi',['AggiornaTubi',['../aggiornamenti_8cc.html#af78f60b7452e4c4027f59b9077f780ae',1,'aggiornamenti.cc']]]
];
