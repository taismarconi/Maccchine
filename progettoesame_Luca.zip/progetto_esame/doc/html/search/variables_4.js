var searchData=
[
  ['maxcollisione1',['maxCollisione1',['../structTubi.html#a165f9d47289a34198ea2ab702a77f74f',1,'Tubi']]],
  ['maxcollisione2',['maxCollisione2',['../structTubi.html#ad7b5b1ade365705231d0ca7702d58bed',1,'Tubi']]],
  ['mov',['MOV',['../strutt__dati_8h.html#a9e1e82fbf0bb57d4846f01ade7454fae',1,'strutt_dati.h']]]
];
