var searchData=
[
  ['tema',['tema',['../structSfondo.html#a2201e2aa68e0dd9f9a775a63dc50408b',1,'Sfondo']]],
  ['tubi2',['tubi2',['../structTubi.html#aa5d47d2b8e6c1586ae5f9f0105209354',1,'Tubi']]]
];
