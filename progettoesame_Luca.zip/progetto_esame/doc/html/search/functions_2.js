var searchData=
[
  ['inizializza_5fgiocatore',['inizializza_giocatore',['../inizializzazioni_8cc.html#abe5e896aafa6496ed9316e98690b5972',1,'inizializzazioni.cc']]],
  ['inizializza_5fgioco',['inizializza_gioco',['../inizializzazioni_8cc.html#ab415cd9b711cc1b63f10dd4c08a658f7',1,'inizializza_gioco(ALLEGRO_DISPLAY *&amp;display, ALLEGRO_EVENT_QUEUE *&amp;event_queue, ALLEGRO_TIMER *&amp;timer, int &amp;punteggio, int &amp;tub_conta, int &amp;primoTubo, float &amp;incrementoVelocita, state &amp;stato, bool &amp;inc, Sfondo &amp;background, personaggio &amp;player, ALLEGRO_FONT *scritta[], int &amp;record):&#160;inizializzazioni.cc'],['../inizializzazioni_8h.html#a080fdbd7f6d360cd53ecef01a8628991',1,'inizializza_gioco(ALLEGRO_DISPLAY *&amp;, ALLEGRO_EVENT_QUEUE *&amp;, ALLEGRO_TIMER *&amp;, int &amp;, int &amp;, int &amp;, float &amp;, state &amp;, bool &amp;, Sfondo &amp;, personaggio &amp;, ALLEGRO_FONT *[], int &amp;):&#160;inizializzazioni.cc']]],
  ['inizializza_5finfo',['inizializza_info',['../inizializzazioni_8cc.html#a7fa8d2a5b73d23de9d51d01e27e928db',1,'inizializzazioni.cc']]],
  ['inizializza_5fsfondo',['Inizializza_sfondo',['../inizializzazioni_8cc.html#ae7e55097c7f2d15d3242949281649c10',1,'inizializzazioni.cc']]],
  ['inizializza_5ftubi',['inizializza_tubi',['../inizializzazioni_8cc.html#a0d58072bb1d17c766c8dec3908a5d2c1',1,'inizializza_tubi(Tubi &amp;tub):&#160;inizializzazioni.cc'],['../inizializzazioni_8h.html#a422693dfb63bbaf89b4cc81a43594901',1,'inizializza_tubi(Tubi &amp;):&#160;inizializzazioni.cc']]],
  ['inizializza_5fvariabili',['inizializza_variabili',['../inizializzazioni_8cc.html#ae865e6c6dd2d030bb82cdb4deed45359',1,'inizializzazioni.cc']]]
];
