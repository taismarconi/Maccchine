var searchData=
[
  ['fine',['fine',['../strutt__dati_8h.html#adc6e5733fc3c22f0a7b2914188c49c90a1aeb85029f9ac98550b4da8729f91f3e',1,'strutt_dati.h']]]
];
