var searchData=
[
  ['pausa',['pausa',['../strutt__dati_8h.html#adc6e5733fc3c22f0a7b2914188c49c90afdaf641476048d1efd67c1708ac3e76d',1,'strutt_dati.h']]]
];
