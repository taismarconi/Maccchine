var searchData=
[
  ['aggiornamenti_2ecc',['aggiornamenti.cc',['../aggiornamenti_8cc.html',1,'']]],
  ['aggiornamenti_2eh',['aggiornamenti.h',['../aggiornamenti_8h.html',1,'']]]
];
