var searchData=
[
  ['personaggio',['personaggio',['../structpersonaggio.html',1,'']]]
];
