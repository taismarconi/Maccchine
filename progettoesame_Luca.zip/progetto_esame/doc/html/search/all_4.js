var searchData=
[
  ['game_5fover',['game_over',['../structSfondo.html#a23d10725ed048927a05471db126b2790',1,'Sfondo']]],
  ['giocatore_5finizio',['giocatore_inizio',['../structpersonaggio.html#ae7d38be81e1aebf6346198aff7b0c1de',1,'personaggio']]],
  ['giocatore_5fmovimento',['giocatore_movimento',['../structpersonaggio.html#a9f74569c277f0fee07f1f55e0ed764d8',1,'personaggio']]],
  ['gravity',['gravity',['../structpersonaggio.html#ae6f6a737b20178a833cd93e685eaee2d',1,'personaggio']]]
];
