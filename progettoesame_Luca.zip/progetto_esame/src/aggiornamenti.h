/**\file inizializzazioni.h
* File contenente l'interfaccia del modulo aggiornamento
**/

/**Aggiorna il gioco, richiamando tutte le relative funzioni di aggiornamento.
*
*@param tubo[] Viene passato alla funzione ::AggiornaTubi (vedere la relativa documentazione per dettagli).
*@param player Viene passato alla funzione ::AggiornaTubi e ::AggiornaPlayer (vedere la relativa documentazione per dettagli).
*@param primoTubo Viene passato alla funzione ::AggiornaTubi (vedere la relativa documentazione per dettagli).
*@param tub_conta Viene passato alla funzione ::AggiornaTubi (vedere la relativa documentazione per dettagli).
*@param stato Viene passato a tutte le funzioni di aggiornamento (vedere la relativa documentazione per dettagli).
*@param punteggio Viene passato alla funzione ::AggiornaTubi e ::AggiornaStato (vedere la relativa documentazione per dettagli).
*@param incrementoVelocita Viene passato alla funzione ::AggiornaTubi (vedere la relativa documentazione per dettagli).
*@param inc Viene passato alla funzione ::AggiornaTubi (vedere la relativa documentazione per dettagli).
*@param scritta[] Viene passato alla funzione ::AggiornaStato (vedere la relativa documentazione per dettagli).
*@param record Viene passato alla funzione ::AggiornaStato (vedere la relativa documentazione per dettagli).
*@param background Viene passato alla funzione ::AggiornaStato e ::AggiornaSfondo (vedere la relativa documentazione per dettagli).
*@param calcolo Viene passato alla funzione ::AggiornaPlayer (vedere la relativa documentazione per dettagli).
**/
void aggiorna_gioco (Sfondo &background, state &stato, personaggio &player, float calcolo, Tubi tubo[], int &primoTubo, int &tub_conta, int &punteggio, float &incrementoVelocita, bool &inc, ALLEGRO_FONT *scritta[], int &record);

/** Fine interfaccia del modulo aggiornamento **/
