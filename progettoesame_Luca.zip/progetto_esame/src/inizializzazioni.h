/**\file inizializzazioni.h
* File contenente l'interfaccia del modulo inizializzazione
**/

/** Inizializza le impostazioni generali di allegro 5 e del gioco
*
*
*Inizializza allegro, abilita la tastiera, il supporto delle immagini, del font; richiama le funzioni ::crea_timer, 
*::crea_display, ::crea_eventi, nonché tutte le altre funzioni di inizializzazione del gioco(vedere la relativa documentazione per
* maggiori infrmazioni.
*@param display Viene passato alla funzione ::crea_display.
*@param timer Viene passato alla funzione ::crea_timer.
*@param event_queue Viene passato insieme agli altri due parametri formali alla funzione ::crea_eventi.
*@param punteggio Viene passato alla funzione ::inizializza_variabili.
*@param tub_conta Viene passato alla funzione ::inizializza_variabili.
*@param primoTubo Viene passato alla funzione ::inizializza_variabili.
*@param incrementoVelocita Viene passato alla funzione ::inizializza_variabili.
*@param stato Viene passato alla funzione ::inizializza_variabili.
*@param inc Viene passato alla funzione ::inizializza_variabili.
*@param background Viene passato alla funzione ::Inizializza_sfondo.
*@param player Viene passato alla funzione ::inizializza_giocatore.
*@param scritta Viene passato alla funzione ::inizializza_info.
*@param record Viene passato alla funzione ::inizializza_info insieme al parametro scritta[].
*@return Tale funzione ritorna -1 in caso di errore nel richiamare qualche funzione di allegro 5, 0 in caso di esecuzione corretta
**/
int inizializza_gioco(ALLEGRO_DISPLAY *&, ALLEGRO_EVENT_QUEUE *&, ALLEGRO_TIMER *&, int &, int &, int &, float &, state &, bool &, Sfondo &, personaggio &, ALLEGRO_FONT *[], int &);


/** Inizializza i tubi.
*
*
*Attribuisce una forma e un'immagine ai tubi da generare, decidendo in modo casuale quale immagine attribuirgli. In base alla 
*coppia di immagini assegnate ai tubi di ogni singola posizione del vettore Tubi, sarà assegnata a ogni tubo una posizione 
*sull'asse delle y diversa, nonché di diverso valore saranno le variabili che indicano la lunghezza del tubo in basso e del tubo 
*in alto.
*@param tub Variabile di tipo Tubi (vedere il file strutt_dati.h per  ulteriori dettagli in merito).Tale parametro formale non è 
*altro che una cella del vettore di struct, passata per riferimento nel ::main all'interno di un ciclo che richiama questa 
*funzione dieci volte, inizializzando così 10 tubi con immagini e valori diversi.
**/
void inizializza_tubi(Tubi &);

/** Fine interfaccia del modulo inizializzazione **/
