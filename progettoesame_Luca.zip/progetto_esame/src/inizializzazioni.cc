/**\file inizializzazioni.cc
  *In questo file sono contenute tutte le funzioni di inizializzazione e avvio del gioco, delle
  *variabili, dei tubi, del
  *personaggio e delle immagini. Tutte le funzioni presenti in questo file sono private e non
  *presenti nell'interfaccia del
  *modulo, eccetto ::inizializza_tubi, che viene richiamata dal main e dalla funzione che aggiorna i
  *tubi. Tutte le funzioni
  *di questo file consentono la creazione e l'inizializzazione delle impostazioni di gioco, e
  *vengono reinizializzate ogni nuova
  *partita. Questo viene fatto prima che il giocatore inizi a giocare, per evitare che il gioco vada
  *in corso a rallentamenti
  *causati da inizializzazioni e caricamenti durante l'esecuzione.
**/
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <fstream>
#include <allegro5/allegro_ttf.h>
#include "strutt_dati.h"
#include "inizializzazioni.h"
/**
*Impostazione del debug
**/
#ifdef DEBUG_MODE
extern unsigned int mask;
#define DBG(A, B)                                                                                  \
    {                                                                                              \
        if ((A)&mask)                                                                              \
        {                                                                                          \
            B;                                                                                     \
        }                                                                                          \
    }
#else
#define DBG(A, B)
#endif
/**
*La seguente definizione non è necessaria ma è comoda in quanto consente di scrivere D1(...) al posto di DBG (2, ...).
**/
#define D1(a) DBG(2, a)
using namespace std;

// Inizio definizioni delle funzioni del modulo inizializzazione

/** Inizializza le scritte e il record.
*
*
*Mentre il record è un valore che viene caricato da file di testo, le scritte hanno una dimensione e
*un carattere sempre uguale
*ogni volta che vengono caricate. Questa funzione è privata, ossia non fa parte dell'interfaccia del
*modulo.
*@param scritta[] Ogni posizione del vettore viene inizializzata con lo stesso font, ma con diversa
*dimensione
*@param record Il valore di questa variabile è caricata dal file file.txt
**/
void inizializza_info(ALLEGRO_FONT* scritta[], int& record)
{

    scritta[0] = al_load_ttf_font(
        "/home/luca/Scrivania/progetto_esame/media/All_Star_Resort.ttf", 70, 0);
    scritta[1] = al_load_ttf_font(
        "/home/luca/Scrivania/progetto_esame/media/All_Star_Resort.ttf", 120, 0);
    scritta[2] = al_load_ttf_font(
        "/home/luca/Scrivania/progetto_esame/media/All_Star_Resort.ttf", 150, 0);
    scritta[3] = al_load_ttf_font("/home/luca/Scrivania/progetto_esame/media/All_Star_Resort.ttf", 30, 0);
    ifstream f("/home/luca/Scrivania/progetto_esame/src/file.txt");
    if (!f)
    {

        cerr << "Errore di lettura del file!" << endl;
        return;
    }
    f >> record;
}
/** Inizializza le immagini di stato del gioco
*
*
*La schermata di game over quando ci si scontra con un tubo o con il suolo, oppure l'immagine di
*pausa che appare quando si preme
*il pulsante invio, nonché il tema principale e la schermata iniziale vengono inizializzate qui.
*Questa funzione è privata, ossia
*non fa parte dell'interfaccia del modulo.
*@param bg variabile di tipo sfondo (vedere il file strutt_dati.h per  ulteriori dettagli in merito)
*definita nel ::main e passata
*come riferimento.
**/
void Inizializza_sfondo(Sfondo& bg)
{

    D1(cout << "Controllo dettagliato funzione Inizializza_sfondo:" << endl);
    D1(cout << "\tInizializzazione del tema di gioco.....");
    bg.tema = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/sfondo.jpg");
    D1(cout << "Fatto!" << endl);
    D1(cout << "\tInizializzazione del tema iniziale.....");
    bg.start = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/sfondo_inizio.jpg");
    D1(cout << "Fatto!" << endl);
    D1(cout << "\tInizializzazione dell'immagine di pausa.....");
    bg.pause = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/pausa1.png");
    D1(cout << "Fatto!" << endl);
    D1(cout << "\tGenerazione del pavimento.....");
    bg.pavimento = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/pav1.png");
    D1(cout << "Fatto!" << endl);
    D1(cout << "\tGenerazione della schermata di game over.....");
    bg.game_over[0] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/game_over1.png");
    bg.game_over[1] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/game_over2.png");
    bg.game_over[2] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/game_over3.png");
    D1(cout << "Fatto!" << endl);
}

/** Inizializza il giocatore.
*
*
*Le caratteristiche del player sono inizializzate qui, l'altezza complessiva di salto, la sua
*posizione, la sua immagine iniziale
*e quella in movimento. Questa funzione è privata, ossia non fa parte dell'interfaccia del modulo.
*@param player Variabile di tipo personaggio (vedere il file strutt_dati.h per  ulteriori dettagli
*in merito) definita nel ::main
*e passata come riferimento.
**/
void inizializza_giocatore(personaggio& player)
{

    D1(cout << "Controllo dettagliato funzione inizializza_giocatore:" << endl);
    D1(cout << "\tInizializzazione altezza massima di salto del giocatore.....");
    player.velocity = 60;
    D1(cout << "Fatto!" << endl);
    D1(cout << "\tInizializzazione della posizione del giocatore.....");
    player.posX = SCREEN_W / 2 - 300;
    player.posY = SCREEN_H / 2 - 100;
    D1(cout << "Fatto!" << endl);
    D1(cout << "\tInizializzazione delle immagini del giocatore.....");
    player.giocatore_inizio[0] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/0.png");
    player.giocatore_inizio[1] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/1.png");
    player.giocatore_inizio[2] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/2.png");
    player.giocatore_inizio[3] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/3.png");
    player.giocatore_inizio[4] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/4.png");
    player.giocatore_inizio[5] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/5.png");
    player.giocatore_inizio[6] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/6.png");
    player.giocatore_inizio[7] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/7.png");
    player.giocatore_movimento[0] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/5_rs.png");
    player.giocatore_movimento[1] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/4_rs.png");
    player.giocatore_movimento[2] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/3_rs.png");
    player.giocatore_movimento[3] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/2_rs.png");
    player.giocatore_movimento[4] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/1_sr.png");
    player.giocatore_movimento[5] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/0.png");
    player.giocatore_movimento[6] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/1_r.png");
    player.giocatore_movimento[7] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/2_r.png");
    player.giocatore_movimento[8] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/3_r.png");
    player.giocatore_movimento[9] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/4_r.png");
    player.giocatore_movimento[10] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/5_r.png");
    D1(cout << "Fatto!" << endl);
}

void inizializza_tubi(Tubi& tub)
{
    D1(cout << "Controllo dettagliato funzione inizializza_tubi:" << endl);
    int x;
    D1(cout << "\tGenerazione di un numero casuale in base al quale sarà generata una coppia di "
               "tubi differente.....");
    do
    {
        x = rand() % 3;
    } while (x < 0);
    D1(cout << "Fatto!" << endl);
    D1(cout << "\tInizializzazione della coppia di tubi: ");
    switch (x)
    {

        case 0:
        {
            D1(cout << "\n\tGenerazione delle immagini.....");
            tub.tubi2[0] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/tubo1.png");
            tub.tubi2[1] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/tubo2.png");
            D1(cout << "Fatto!" << endl);
            D1(cout << "\tInizializzazione delle posizioni sull'asse X e Y.....");
            tub.posX1 = SCREEN_W - 50;
            tub.posY1 = SCREEN_H - 295;
            tub.posY2 = 0;
            D1(cout << "Fatto!" << endl);
            D1(cout << "\tInizializzazione dell'altezza della coppia di tubi.....");
            tub.maxCollisione1 = SCREEN_H - 350;
            tub.maxCollisione2 = 155;
            D1(cout << "Fatto!" << endl);
            break;
        }

        case 1:
        {
            D1(cout << "\n\tGenerazione delle immagini.....");
            tub.tubi2[0] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/tubo3.png");
            tub.tubi2[1] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/tubo6.png");
            D1(cout << "Fatto!" << endl);
            D1(cout << "\tInizializzazione delle posizioni sull'asse X e Y.....");
            tub.posX1 = SCREEN_W - 50;
            tub.posY1 = SCREEN_H - 220;
            tub.posY2 = -10;
            D1(cout << "Fatto!" << endl);
            D1(cout << "\tInizializzazione dell'altezza della coppia di tubi.....");
            tub.maxCollisione1 = SCREEN_H - 278;
            tub.maxCollisione2 = 285;
            D1(cout << "Fatto!" << endl);
            break;
        }

        case 2:
        {
            D1(cout << "\n\tGenerazione delle immagini.....");
            tub.tubi2[0] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/tubo5.png");
            tub.tubi2[1] = al_load_bitmap("/home/luca/Scrivania/progetto_esame/media/tubo4.png");
            D1(cout << "Fatto!" << endl);
            D1(cout << "\tInizializzazione delle posizioni sull'asse X e Y.....");
            tub.posX1 = SCREEN_W - 50;
            tub.posY1 = SCREEN_H - 463;
            tub.posY2 = -10;
            D1(cout << "Fatto!" << endl);
            D1(cout << "\tInizializzazione dell'altezza della coppia di tubi.....");
            tub.maxCollisione1 = SCREEN_H - 520;
            tub.maxCollisione2 = 72;
            D1(cout << "Fatto!" << endl);
            break;
        }
    }

    D1(cout << "\tInizializzazione della velocità.....");
    tub.velocity = 5;
    D1(cout << "Fatto!" << endl);
    tub.fuori_schermo = false;
}

/** Inizializza il timer di gioco.
*
*
*Imposta il timer di gioco alla veocità di 1/150, dove 150 sono i frame per secondo (FPS). Questa
*funzione è privata, ossia non fa
* parte dell'interfaccia del modulo.
*@param timer Variabile di tipo ALLEGRO_TIMER dichiarata nel ::main
*@return Tale funzione ritorna -1 in caso di errore nel richiamare al_create_timer, 0 in caso di
*chiamata corretta
**/
int crea_timer(ALLEGRO_TIMER*& timer)
{

    timer = al_create_timer(1.0 / FPS);
    if (!timer)
    {

        cerr << "errore nella creazione del timer!\n";
        return -1;
    }
    return 0;
}

/** Crea il display di gioco.
*
*Questa funzione è privata, ossia non fa parte dell'interfaccia del modulo.
*@param display Variabile di tipo ALLEGRO_DISPLAY passata per riferimento e dichiarata nel ::main
*@return Tale funzione ritorna -1 in caso di errore nel richiamare al_create_display, 0 in caso di
*chiamata corretta
**/
int crea_display(ALLEGRO_DISPLAY*& display)
{

    display = al_create_display(
        SCREEN_W, SCREEN_H); // Decido così le dimensioni del mio display di gioco
    if (!display)
    {
        cerr << "Errore nella creazione del display!\n";
        return -1;
    }

    al_clear_to_color(al_map_rgb(250, 250, 250));
    return 0;
}

/** Crea la coda di eventi del gioco.
*
*
*Dopo la creazione, associa il display, il timer e la tastiera a eventi, vengono quindi riconosciuti
*come tali e inseriti nella
*coda di eventi quando necesssario e saranno quindi gestiti. Questa funzione è privata, ossia non fa
*parte dell'interfaccia del
*modulo.
*@param event_queue Variabile di tipo ALLEGRO_EVENT_QUEUE passata per riferimento, rappresenta la
*coda di eventi.
*@param display Qui lego effettivamente il display alla coda degli eventi, così possiamo essere
*informati degli eventi dal
*display come l'evento di chiusura del gioco (X rossa in alto a sinistra del display).
*@param timer Viene passato a questa funzione per legare così timer alla coda degli eventi.
*@return Tale funzione ritorna -1 in caso di errore nel richiamare al_create_event_queue(), 0 in
*caso di chiamata corretta
**/
int crea_eventi(ALLEGRO_EVENT_QUEUE*& event_queue, ALLEGRO_DISPLAY*& display, ALLEGRO_TIMER*& timer)
{

    event_queue = al_create_event_queue();
    if (!event_queue)
    {

        cerr << "Errore nella creazione della coda di eventi!\n";
        return -1;
    }

    al_register_event_source(event_queue, al_get_display_event_source(display));
    al_register_event_source(event_queue, al_get_timer_event_source(timer));
    al_register_event_source(
        event_queue, al_get_keyboard_event_source()); // lego la tastiera alla coda di eventi
    return 0;
}

/**Inizializza le variabili locali di gioco.
*
*Questa funzione è privata, ossia non fa parte dell'interfaccia del modulo.
*@param punteggio Valore intero che si incrementa di 1 ogni tubo superato; viene inizializzato a 0 a
*inizio gioco.
*@param tub_conta Variabile intera che permette di contare i tubi; si incrementa tutte le volte che
*l'ultimo tubo generato
*raggiunge una certa posizione, in modo tale da rendere possibile generare un nuovo tubo che parte
*da fine schermo.
*@param primoTubo Variabile intera che indica il primo tubo visibile sullo schermo, ogni volta che
*un tubo esce dallo schermo
*questa si incrementa poiché il primo tubo visibile da quel momento è un altro.
*@param incrementoVelocita Variabile che indica di quanto deve aumentare la velocità ogni dieci
*tubi.
*@param stato Enumerato che mostra lo stato del gioco, indica cioè se il gioco è in corso, in pausa,
*in game over o nello
*stato iniziale.
*@param inc Variabile che consente l'incremento del punteggio se essa è true.
**/
void inizializza_variabili(int& punteggio, int& tub_conta, int& primoTubo,
    float& incrementoVelocita, state& stato, bool& inc)
{

    incrementoVelocita = 1.;
    primoTubo = 0;
    tub_conta = 0;
    stato = inizio;
    punteggio = 0;
    inc = true;
}

int inizializza_gioco(ALLEGRO_DISPLAY*& display, ALLEGRO_EVENT_QUEUE*& event_queue,
    ALLEGRO_TIMER*& timer, int& punteggio, int& tub_conta, int& primoTubo,
    float& incrementoVelocita, state& stato, bool& inc, Sfondo& background, personaggio& player,
    ALLEGRO_FONT* scritta[], int& record)
{

    D1(cout << "inizializzazione di allegro.....");
    if (!al_init())
    {

        cerr << "Errore nell' inizializzazione di allegro!\n";
        return -1;
    }
    D1(cout << "Fatto!" << endl);
    D1(cout << "inizializzazione tastiera.....");
    if (!al_install_keyboard())
    {

        cerr << "Errore nell' inizializzazione della tastiera!\n";
        return -1;
    }
    D1(cout << "Fatto!" << endl);
    D1(cout << "inizializzazione immagini.....");
    if (!al_init_image_addon())
    {

        cerr << "Errore nell' inizializzazione delle immagini!\n";
        return -1;
    }
    D1(cout << "Fatto!" << endl);
    D1(cout << "inizializzazione del font e del carattere.....");
    al_init_font_addon();
    al_init_ttf_addon();
    D1(cout << "Fatto!" << endl);
    D1(cout << "inizializzazione del timer, del display e della coda di eventi.....");
    if (crea_timer(timer) < 0 || crea_display(display) < 0
        || crea_eventi(event_queue, display, timer) < 0)
    {

        return -1;
    }
    D1(cout << "Fatto!" << endl);
    D1(cout << "Inizializzazione delle variabili di gioco.....");
    inizializza_variabili(punteggio, tub_conta, primoTubo, incrementoVelocita, stato,
        inc); // Inizializza le variabili di gioco
    D1(cout << "Fatto!" << endl);
    D1(cout << "Inizializzazione dello sfondo di gioco.....");
    Inizializza_sfondo(background); // Inizializza tutti gli sfondi di gioco.
    D1(cout << "Inizializzazione delle caratteristiche del personaggio.....");
    inizializza_giocatore(player); // Inizializza tutte le caratteristiche del giocatore.
    D1(cout << "Creazione e inizializzazione del font grafico e del record.....");
    inizializza_info(scritta, record); // Inizializza la variabile scritta e il record di gioco.
    D1(cout << "Fatto!" << endl);

    return 0;
}
