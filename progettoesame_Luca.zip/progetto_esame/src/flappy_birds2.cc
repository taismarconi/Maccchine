/**
        *@mainpage DOCUMENTAZIONE DEL PROGETTO
        *@brief
        *Flappy Birds è il gioco che ho deciso di implementare utilizzando le librerie grafiche di allegro, la cui documentazione
        *è realizzata con Doxygen versione 1.8.11.
        *Continuando la lettura si vedranno i siti web utilizzati per poter realizzare il progetto e la documentazione, nonché 
        *tutti gli strumenti utilizzati ed i procedimenti eseguiti per poter realizzare questo gioco.
		*Vengono successivamente inserite informazioni relative al gioco e alle diverse prove eseguite per ottenere il progetto
		*finale. Leggendo il codice si troverà un commento più dettagliato e 
        *un commento sintetico relativo ai comandi più semplici da comprendere, mentre ho inserito commento di spiegazione in cui è
        * accurato nelle righe di codice più complesse. In tutti e tre i file sorgente è previsto un 
        *spiegata la divisione logica e la modulazione delle diverse funzionalità del gioco; ogni funzione è a sua volta 
        *commentata in modo dettagliato, così come le righe di codice in essa contenute. 
        *Detto questo, DIAMO IL VIA ALLA LETURA!<br>
        *@author Luca Reggiani <br>
        *
        *<h4>Sitografia:</h4>
          *<a href="https://it.wikipedia.org/wiki/Allegro_(libreria_software)">https://it.wikipedia.org/wiki/Allegro_(libreria_software)</a><br>
          *<a href="http://liballeg.org">http://liballeg.org</a> <br>
          *<a href="https://wiki.allegro.cc">https://wiki.allegro.cc</a> <br>
          *<a href="https://forum.html.it/forum">https://forum.html.it/forum</a> <br>
          *<a href="http://www.stack.nl/~dimitri/doxygen/manual/index.html">http://www.stack.nl/~dimitri/doxygen/manual/index.html</a> <br>
          *<a href="https://www.star.bnl.gov/public/comp/sofi/doxygen/docblocks.html">https://www.star.bnl.gov/public/comp/sofi/doxygen/docblocks.html</a><br>

        *<h4>Altri link:</h4>
          *<a href="https://forum.ubuntu-it.org/viewtopic.php?t=436424">https://forum.ubuntu-it.org/viewtopic.php?t=436424</a> <br>

    *<h4>Bibliografia:</h4>
      *Slides esposte a lezione
    *<h3>INFORMAZIONI SUL GIOCO:</h3>
    *Flappy birds è un gioco realmente esistente e da quello ho preso spunto per l'idea del progetto, non lasciandolo tuttavia 
    *invariato, in quanto alcuni effetti o funzionalità sono personalizzati da me (per esempio, avete notato cosa accade ogni 10
    * tubi superati? :-) ).
    *Il gioco è stato scritto in c++, realizzato con gedit e utilizza le librerie di allegro 5. Inizialmente è stato sviluppato su
    * un singolo file, diviso già in funzioni. Tuttavia così facendo il codice andava incontro a problemi di comprensione e di 
    *ordine, nonché ci furono grossi rallentamenti. Successivamente a causa della lunghezza e complessità del sorgente decisi di 
    *dividere in più file il codice iniziale, riscrivendolo tutto in modo più ordinato. È così che è stato possibile realizzare 
    *questo gioco. Nel codice si può notare almeno una riga di commento per ogni riga, nonché l'utilizzo delle macro per 
    *effettuare il debug in modo semplice e immediato. Ogni file ha tutte le librerie che sono necessarie per la sua esecuzione:
    * librerie del c++, quelle di allegro e, infine, gli headers dei file utilizzati. Le immagini sono state prese dal web e 
    *modificate dall'applicazione grafica gimp, recensita come una delle migliori e suggerita da molti utenti del forum (link del 
    *forum nella sezione altri link).
    *
    *<h3>COME AVVIARE IL GIOCO:</h3>
    *Aprite un terminale e digitate cd Scrivania/progetto_esame/src. In tal modo dovreste trovarvi
nella directory corretta
        *dove sono presenti i seguenti file sorgente:

                * flappy_birds.cc
                * aggiornamenti.cc
                * inizializzazioni.cc

        *inoltre sono presenti i seguenti headers file:

                *strutt_dati.h
                *aggiornamenti.h
                *inizializzazioni.h

        *e l'eseguibile:

                *exe

        *Ora:<br>
                <ul>
                *<li>Digitare sul terminale <i>./exe</i>, verrà quindi eseguito il file eseguibile predentemente creato, frutto 
                *della precedente compilazione del codice;

                *<li>In caso di problemi digitare <i>make</i>. In tal modo si va a ricompilare il makefile, generando un nuovo 
                *eseguibile;

                *<li>È possibile anche compilare il programma scrivendo sul terminale <i>g++ flappy_birds2.cc inizializzazioni.cc 
                *aggiornamenti.cc -o exe `pkg-config --cflags --libs allegro-5 allegro_color-5 allegro_image-5 allegro_font-5 
                *allegro_primitives-5 allegro_ttf-5`</i> e avviare l'eseguibile generato seguendo quanto detto nel punto 1.

				*<li>Digitando <i>make clean</i> si cancella l'eseguibile generato (in caso si voglia ricompilare il gioco).
				*<li>Infine, digitando <i>make debug</i> si compila il gioco in modalità debug.
                </ul>
        *
        *<h3>COME GIOCARE:</h3>
        *Il gioco parte dalla schermata di inizio gioco, per farlo partire basta premere uno dei due tasti indicati dalla schermata
        * iniziale, visibili anche nell'immagine seguente:
        *<img src="/home/luca/Scrivania/progetto_esame/media/key0.png">
        *Premendo il pulsante invio durante il gioco è possibile mettere in pausa, o viceversa riprendere a giocare. Se si preme  
        *tale tasto nella schermata di game over è possibile ricominciare il gioco.
**/
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_ttf.h>
#include <cstdlib>
#include <iostream>
#include <ctime>
#include "strutt_dati.h"
#include "inizializzazioni.h"
#include "aggiornamenti.h"
using namespace std;
/**
*Impostazione del debug
**/
#ifdef DEBUG_MODE
unsigned int mask = 1;
#define DBG(A, B)                                                                                  \
    {                                                                                              \
        if ((A)&mask)                                                                              \
        {                                                                                          \
            B;                                                                                     \
        }                                                                                          \
    }
#else
#define DBG(A, B)
#endif
/**
*La seguente definizione non è necessaria ma è comoda in quanto consente di scrivere D1(...) al posto di DBG (1, ...).
**/
#define D1(a) DBG(1, a)
/**Funzione principale del gioco.
  *
  *dentro di essa avvengono tutti i richiami alle funzioni di inizializzazione e aggiornamento,
  *nonché il cambiamento delle
  * variabili di gioco non appena si clicca un pulsante.
  *
**/

int main(int argc, char** argv)
{

    D1(cout << "Dichiarazione delle variabili di gioco.....");
    bool ricomincia; // Indica se il gioco va ricominciato o se bisogna restare nella schermata del
                     // game over.
    bool inc;
    int record; // Valore intero destinato alla memorizzazione del record, viene mostrato nella
                // schermata di game over.
    int punteggio, tub_conta, primoTubo;
    float incrementoVelocita;
    float calcolo; // Variabie di appoggio di tipo float usata per memorizzare il risultato di
                   // un'espressone di calcolo; grazie a
    // tale valore il personaggio salta sempre alla stessa altezza.
    state stato;
    D1(cout << "Fatto!" << endl);
    ALLEGRO_DISPLAY* display = NULL; // variabile usata per rappresentare il display di gioco
    /*
            ciclo infinito dentro il quale viene eseguito il gioco, quando il gioco finisce premendo
       invio si riparte dall'inizio di
            questo ciclo e il gioco ricomincia
    */
    while (true)
    {

        ricomincia = false;
        ALLEGRO_EVENT_QUEUE* event_queue
            = NULL; // variabile usata per rappresentare la coda di eventi a cui devono essere
        // associate le diverse variabili rappresentanti il timer, il display,....

        ALLEGRO_TIMER* timer = NULL; // variabile che indica la velocità di gioco basandosi su 60
                                     // frame per secondo, è
        // inizializzata nella funzione crea_timer del file inizializzazioni.cc

        ALLEGRO_FONT* scritta[4]; // vettore di font contenente il font utilizzato nel gioco, in
                                  // ogni cella del vettore si avrà
        // una dimensione diversa o una scritta diversa, ma lo stile del carattere è invariato in
        // quanto
        // ho utilizzato un solo font

        Sfondo background; // variabile che mi indica lo sfondo, è di tipo Sfondo cioè una struct
                           // definita in strutt_dati.h

        personaggio player; // fa riferimento al giocatore. È di tipo personaggio, cioè una struct
                            // definita in strutt_dati.h

        Tubi tubo[10]; // variabile riferita ai tubi, dove in ogni indice del vettore ci sono tubi
                       // diversi. È di tipo Tubi,
        // anche questa è una struct definita in strutt_dati.h

        bool key[3] = { false, false, false };
        bool esci = false; // Se true, chiude il gioco.
        D1(cout << "Inizializzazione del gioco.....");
        inizializza_gioco(display, event_queue, timer, punteggio, tub_conta, primoTubo,
            incrementoVelocita, stato, inc, background, player, scritta, record);
        for (int i = 0; i < 10; i++)
        {

            D1(cout << "\nInizializzazione del tubo in posizione " << i << ".....");
            inizializza_tubi(tubo[i]); // Inizializza tubo per tubo di un vettore di dieci tubi.
        }
        D1(cout << "\nAvvio del timer di gioco.....");
        al_start_timer(
            timer); // funzione di allegro che avvia il timer di gioco precedentemente inizializzato
        D1(cout << "Ok!" << endl);
        srand((unsigned)time(NULL));
        D1(cout << "Avvio del gioco.....");
        while (!esci)
        {

            ALLEGRO_EVENT evento; // variabile evento.
            al_wait_for_event(event_queue, &evento); // Attende fino a che la coda di eventi
                                                     // specificata (primo parametro passato)
            // ha almeno un elemento. Se la variabile evento non è nulla il primo elemento
            // in coda sarà copiato in evento e rimosso dalla coda. Se la variabile
            // evento è nulla allora il primo elemento della coda è lasciato alla testa
            // della coda.

            if (evento.type == ALLEGRO_EVENT_TIMER)
            { // Controllo il tipo di evento, se è un evento timer allora la condizione è
                // verificata.

                if (player.gravity == true && player.posY <= 540 && player.conta == 2)
                {

                    player.posY += 1;
                    if (player.conta == 2)
                    {

                        player.posY += 0.5;
                    }
                }
                if (key[KEY_UP] && player.conta == MOV - 1)
                { // Condizione verificata solo se avevo premuto la freccia su e il
                    // personaggio guarda verso l'alto

                    player.gravity = true; // Abilito la gravità
                }


                if (key[KEY_SPACE] && player.conta == MOV - 1)
                {

                    player.gravity = true;
                }
            }

            if (evento.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
            { // Se clicco la X rossa in alto a sinistra si esce dal gioco

                return 0;
            }

            else if (evento.type == ALLEGRO_EVENT_KEY_DOWN)
            { // Se il tipo di evento equivale alla pressione di un pulsante.

                switch (evento.keyboard.keycode)
                { // switch case dei possibili tasti premuti

                    case ALLEGRO_KEY_UP:
                    { // Freccia su

                        if (stato == inizio || stato == in_corso)
                        {
                            calcolo = player.velocity
                                / (MOV - player.conta); // inizializzazione della variabile calcolo.
                            stato = in_corso;
                            key[KEY_UP] = true; // Tengo presente che ho cliccato la freccia su
                            player.gravity = false; // Disabilito la gravità
                        }
                        break;
                    }

                    case ALLEGRO_KEY_SPACE:
                    { // Barra spaziatrice

                        if (stato == inizio || stato == in_corso)
                        {
                            calcolo = player.velocity / (MOV - player.conta);
                            stato = in_corso;
                            key[KEY_SPACE] = true;
                            player.gravity = false;
                        }

                        break;
                    }

                    case ALLEGRO_KEY_ENTER:
                    { // Pulsante invio

                        if (stato == in_corso)
                        { // Se lo stato del gioco è in corso allora la partita va in pausa

                            stato = pausa;
                            player.gravity = false; // Disabilito la gravità del giocatore
                            key[KEY_UP] = false; // Disabilito il salto
                            key[KEY_SPACE] = false;
                        }

                        else if (stato == pausa)
                        { // Se lo stato del gioco è in pausa allora la partita riprende

                            stato = in_corso;
                            player.gravity = true; // riattivo la gravità del giocatore
                        }
                        else if (stato == fine)
                        { // Se lo stato del gioco è in game over allorail gioco ricomincia da capo

                            ricomincia = true;
                        }
                        break;
                    }
                }
                if (ricomincia == true)
                {

                    break; // In tal modo esce dal ciclo più interno e ricomincia quello più
                           // esterno, ricominciando così il gioco.
                }
            }

            else if (player.gravity == true)
            {

                key[KEY_UP] = false;
                key[KEY_SPACE] = false;
            }

            if (player.posY >= 540)
            { // Se il giocatore tocca il suolo il gioco termina e va in game over.

                stato = fine;
                player.gravity = false;
                key[KEY_UP] = false;
                key[KEY_SPACE] = false;
            }
            if (al_is_event_queue_empty(event_queue))
            { // Entra in questo if se e solo se la coda di eventi è vuota, alla fine di
                // ogni ciclo di clock, in tal modo è sensato aggiornare tutto il gioco.
                // Senza questo controllo, il gioco si aggiornerebbe senza che sia stato
                // eseguito ogni evento in coda, portando a problemi nell' avanzamento del
                // gioco.

                if (punteggio > record)
                { // Se il punteggio diventa maggiore del record, quest' ultimo si aggiorna di pari
                  // passo con
                    // il punteggio

                    record++;
                }
                D1(cout << "Aggiornamento del gioco....." << endl);
                aggiorna_gioco(background, stato, player, calcolo, tubo, primoTubo, tub_conta,
                    punteggio, incrementoVelocita, inc, scritta, record);
                D1(cout << "Fatto!" << endl);
                al_flip_display(); // Aggiorna tutto il display.
            }
        }
        D1(cout << "Disattivazione del timer di gioco.....");
        al_destroy_timer(timer); // Disattivazione del timer di gioco
        D1(cout << "Fatto!" << endl);
        D1(cout << "Distruzione della coda di eventi.....");
        al_destroy_event_queue(event_queue); // Disattivazione della coda di eventi
        D1(cout << "Fatto!" << endl << endl << endl);
    }
    D1(cout << "Distruzione del display....." << endl);
    al_destroy_display(display); // Disattivazione del display di gioco
    D1(cout << "Fatto!" << endl);
}
