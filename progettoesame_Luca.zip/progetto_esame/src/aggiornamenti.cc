/**\file aggiornamenti.cc
  *In questo file sono contenute tutte le funzioni di aggiornamento del gioco, vengono gestite le
  *collisioni, viene gestita la
  *rotazione del personaggio, nonché la generazione dello sfondo. Il tutto viene filtrato dal
  *controllo sullo stato di gioco,
  *nel senso che in base allo stato di gioco in cui ci si trova ogni funzione farà qualcosa di
  *diverso.
**/
#include <iostream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <cstdlib>
#include <ctime>
#include <allegro5/allegro_ttf.h>
#include <fstream>
#include "strutt_dati.h"
#include "inizializzazioni.h"
#include "aggiornamenti.h"
using namespace std;
/**
*Impostazione del debug
**/
#ifdef DEBUG_MODE
extern unsigned int mask;
#define DBG(A, B)                                                                                  \
    {                                                                                              \
        if ((A)&mask)                                                                              \
        {                                                                                          \
            B;                                                                                     \
        }                                                                                          \
    }
#else
#define DBG(A, B)
#endif
/**
*La seguente definizione non è necessaria ma è comoda in quanto consente di scrivere D2(...) al posto di DBG (4, ...).
**/
#define D2(a) DBG(4, a)
/**Inserisce le immagini tipiche di sfondo.
*
*Questa funzione è privata, ossia non fa parte dell'interfaccia del modulo.
*In base allo stato di gioco verrà inserita una o più immagini diverse, tipiche di quello stato di
*gioco, quindi se lo stato di
*gioco è game over inserirà il vettore di immagini del game over nonché verrà mostrato il record e
*il punteggio della partita.
*@param bg Viene usato per utilizzare i diversi campi della struct Sfondo, per far apparire
*l'immagine di pausa e di game over.
*@param scritta[] Viene usata per scrivere il punteggio durante il gioco e nella schermata di game
*over, quest'ultima insieme al
*record.
*@param punteggio Variabile utilizzata quando si disegna con il font il punteggio.
*@param record Variabile utilizzata quando si disegna con il font il record nella schermata di game
*over.
*@param stato Enumerato utilizzato qui per il controllo in un if dello stato, in base al quale la
*funzione fa qualcosa di diverso.
**/
void AggiornaStato(Sfondo& bg, ALLEGRO_FONT* scritta[], int& punteggio, int record, state stato)
{

    if (stato == pausa)
    {

        al_draw_bitmap(bg.pause, SCREEN_W / 2 - 200, SCREEN_H / 2 - 200, 0);
    }

    else if (stato == fine)
    {

        al_draw_bitmap(bg.game_over[0], SCREEN_W / 2 - 150, SCREEN_H / 2 - 300, 0);
        al_draw_bitmap(bg.game_over[1], SCREEN_W / 2 - 200, SCREEN_H / 2 - 200, 0);
        al_draw_bitmap(bg.game_over[2], SCREEN_W / 2 - 50, SCREEN_H / 2 + 70, 0);
        if (punteggio < 10)
            al_draw_textf(scritta[0], al_map_rgb(0, 0, 0), SCREEN_W / 2.0 + 190,
                SCREEN_H / 2.0 - 145, 0, "%i", punteggio);
        else
            al_draw_textf(scritta[0], al_map_rgb(0, 0, 0), SCREEN_W / 2.0 + 160,
                SCREEN_H / 2.0 - 145, 0, "%i", punteggio);

        if (record < 10)
            al_draw_textf(scritta[0], al_map_rgb(0, 0, 0), SCREEN_W / 2.0 + 190,
                SCREEN_H / 2.0 - 50, 0, "%i", record);
        else
            al_draw_textf(scritta[0], al_map_rgb(0, 0, 0), SCREEN_W / 2.0 + 160,
                SCREEN_H / 2.0 - 50, 0, "%i", record);

        int valutazione;
        ifstream f("file.txt");
        if (!f)
        {

            cerr << "\nErrore di creazione del file!" << endl;
        }
        f >> valutazione; // carico il vecchio record
        if (valutazione < record)
        { // se è minore di quello atuale allora modifico il file di testo contenente il record
            ofstream f2("file.txt");
            if (!f2)
            {

                cerr << "\nErrore di creazione del file!" << endl;
            }
            f2 << record;
        }
    }

    else if (stato == in_corso)
    {
        if (punteggio % 10 == 0 && punteggio != 0)
        {
            al_draw_textf(scritta[2], al_map_rgb(250, 250, 250), SCREEN_W / 2.0 - 50,
                SCREEN_H / 2.0 - 150, 0, "%i", punteggio);
            al_draw_textf(scritta[1], al_map_rgb(250, 250, 250), rand() % SCREEN_W,
                rand() % SCREEN_H, 0, "%i", punteggio);
            al_draw_textf(scritta[0], al_map_rgb(250, 250, 250), rand() % SCREEN_W,
                rand() % SCREEN_H, 0, "%i", punteggio);
        }
        else
            al_draw_textf(
                scritta[0], al_map_rgb(250, 250, 250), SCREEN_W / 2.0, 0.0, 0, "%i", punteggio);
    }
}

/**Aggiorna lo sfondo del gioco.
*Questa funzione è privata, ossia non fa parte dell'interfaccia del modulo.
*@param bg Viene usato per utilizzare i diversi campi della struct Sfondo, per far apparire
*l'immagine di sfondo e di inizio,
*nonché il pavimento.
*@param stato Enumerato utilizzato qui per il controllo in un if dello stato, in base al quale la
*funzione fa qualcosa di diverso.
**/
void AggiornaSfondo(Sfondo& bg, state stato)
{

    if (stato == in_corso || stato == fine || stato == pausa)
        al_draw_bitmap(bg.tema, 0, 0, 0);
    if (stato == inizio)
        al_draw_bitmap(bg.start, 0, 0, 0);
    al_draw_bitmap(bg.pavimento, 0, 595, 0);
}

/**Aggiorna i tubi e gestisce il loro spostamento, nonché la collisione tra essi e il personaggio.
*Questa funzione è privata, ossia non fa parte dell'interfaccia del modulo.
*@param tubo[] Viene passato in quanto è necessario utilizzare tutto il vettore dei tubi per la loro
*generazione e lo spostamento.
*Viene fatto scorrere elemento per elemento del vettore e, quando si arriva all'ultimo, il vettore
*viene reinizializzato in modo
*tale da assegnare a ogni cella una coppia di tubi probabilmente diversa.
*@param player Variabile passata per poter gestire la collisione con i tubi.
*@param primoTubo Variabile di appoggio destinata a memorizzare la posizione nel vettore di tubi del
*primo tubo visibile sullo
*schermo.
*@param tub_conta Variabile usata per contare i tubi del vettore tubo, viene incrementata di uno
*ogni volta che una coppia di tubi
* viene generata e viene azzerata quando il suo valore è 9.
*@param stato Enumerato utilizzato per il controllo in un if dello stato, in base al quale la
*funzione fa qualcosa di diverso.
*@param punteggio Intero qui usato per incrementare il punteggio di gioco ogni tubo superato con
*successo.
*@param incrementoVelocita Valore float che si incrementa ogni dieci tubi, viene poi sommato alla
*velocità del tubo, sempre uguale.
*@param inc Booleano usato come controllo in un if, nel caso sia true allora il punteggio si
*incrementa, diventando poi false.
**/
void AggiornaTubi(Tubi tubo[], personaggio& player, state& stato, int& primoTubo, int& tub_conta,
    int& punteggio, float& incrementoVelocita, bool& inc)
{

    D2(cout << "Controllo dettagliato funzione AggiornaTubi:" << endl);
    if (stato == pausa)
    { // Controllo lo stato

        for (int i = primoTubo; i <= tub_conta; i++)
        { // Se lo stato è in pausa disegna tutti i tubi nello stesso ordine e modo di
            // quando si è premuto invio. Il ciclo va dal primo all'ultimo tubo visibile

            al_draw_bitmap(tubo[i].tubi2[0], tubo[i].posX1, tubo[i].posY1, 0);
            al_draw_bitmap(tubo[i].tubi2[1], tubo[i].posX1, tubo[i].posY2, 0);
        }
    }

    else if (stato == fine)
    {

        for (int i = primoTubo; i <= tub_conta; i++)
        {

            al_draw_bitmap(tubo[i].tubi2[0], tubo[i].posX1, tubo[i].posY1, 0);
            al_draw_bitmap(tubo[i].tubi2[1], tubo[i].posX1, tubo[i].posY2, 0);
        }
    }

    else if (stato == in_corso)
    {

        D2(cout << "\tStato: in corso. Generazione, movimento ed incremento dei tubi in corso....."
                << endl);
        for (int i = primoTubo; i <= tub_conta; i++)
        { // Controllo tubo per tubo, dal primo visibile all'ultimo presente sul display
            D2(cout << "\tverifica della posizione dei tubi.....");
            if (tubo[i].fuori_schermo == false)
            { // Controllo che il tubo in questione non sia nel frattempo finito fuori schermo

                al_draw_bitmap(
                    tubo[i].tubi2[0], tubo[i].posX1, tubo[i].posY1, 0); // disegno il tubo in basso
                al_draw_bitmap(
                    tubo[i].tubi2[1], tubo[i].posX1, tubo[i].posY2, 0); // disegno il tubo in alto
                tubo[i].posX1 -= tubo[i].velocity; // Cambio la posizione X dei due tubi appena
                                                   // disegnati, in tal modo la volta
                // successiva che verranno disegnati saranno nella posizione appena modificata

                if (tubo[i].posX1 <= -15)
                { // controllo se una certa coppia di tubi esce dallo schermo
                    tubo[i].fuori_schermo = true;
                    primoTubo++; // Aggiorno il primo tubo visibile sullo schermo
                    inc = true;
                }
            }
            D2(cout << "Fatto!" << endl);
        }
        // con i due if successivi gestisco le collisioni coi tubi
        D2(cout << "\tgestione delle collisioni.....");
        if ((tubo[primoTubo].posX1 >= player.posX - 10
                && tubo[primoTubo].posX1 <= player.posX + 70))
        { // Controllo la posizione X del
            // giocatore rispetto ai tubi

            if (player.posY >= tubo[primoTubo].maxCollisione1
                || player.posY <= tubo[primoTubo].maxCollisione2)
            { // Controllo la
                // posizione Y
                // del gioccatore
                // rispetto ai tubi
                stato = fine;
                player.gravity = false;
                return;
            }
        }
        D2(cout << "Fatto!" << endl);
        D2(cout << "\tincremento del punteggio.....");
        // Se il player passa tra due tubi il punteggio si incrementa
        if ((tubo[primoTubo].posX1 + 53 > player.posX && tubo[primoTubo].posX1 < player.posX + 70
                && inc == true))
        {
            punteggio++;
            inc = false;
        }
        D2(cout << "Ok!" << endl);
        D2(cout << "\tGenerazione nuova coppia di tubi....." << endl);
        if (tubo[tub_conta].posX1 <= 700)
        { // Quando l'ultimo tubo visibile raggiunge quella data dimensione viene generato un
            // altro tubo
            if (tub_conta < 9)
                tub_conta++; // incremento il contatore dei tubi
            else if (tubo[9].fuori_schermo == true)
            { // Se il decimo tubo esce dallo schermo inizializza il contatore dei tubi e
                // il primo tubo visibile a 0
                tub_conta = 0;
                primoTubo = 0;
                D2(cout << "\tReinizializzazione dei tubi e incremento della velocità.....");
                for (int x = 0; x < 10; x++)
                { // Ciclo in cui si inizializza di nuovo tutto il vettore di tubi, passando alla
                  // funzione
                    // inizializza_tubi ogni singolo tubo del vettore e incrementandone la velocità
                    inizializza_tubi(tubo[x]);
                    tubo[x].velocity += incrementoVelocita;
                }
                incrementoVelocita += 0.5;
                D2(cout << "Ok!" << endl)
            }
        }
        D2(cout << "\tTubi rigenerati con successo!" << endl);
    }
}

/**Aggiorna il giocatore e la sua rotazione o il suo movimento.
*Questa funzione è privata, ossia non fa parte dell'interfaccia del modulo.
*@param player Viene passato per poter modificare il movimento, la rotazione e la posizione del
*personaggio.
*@param calcolo Variabile utilizzata qui per determinare di quanto deve muoversi verso l'alto ogni
*singola immagine del giocatore
*per poter raggiungere l'altezza di salto definita nella struct personaggio.
*@param stato Enumerato utilizzato per il controllo in un if dello stato, in base al quale la
*funzione fa qualcosa di diverso.
**/
void AggiornaPlayer(personaggio& player, float calcolo, state stato)
{

    D2(cout << "Controllo dettagliato funzione AggiornaPlayer:" << endl);
    if (stato == inizio)
    {

        D2(cout << "\tStato: inizio. Controllo dello stato di gioco....." << endl);
        D2(cout << "\tAggiornamento del vettore di immagini durante lo stato iniziale.....");
        al_draw_bitmap(player.giocatore_inizio[player.conta], player.posX, player.posY, 0);
        if (player.conta < INIZIO - 1)
            player.conta++;
        else
            player.conta = 0;
        D2(cout << "Fatto!" << endl);
    }

    else if (stato == in_corso)
    {

        D2(cout << "\tStato: in corso. Aggiornamento del vettore di immagini durante la partita "
                   "(rotazione).....");
        al_draw_bitmap(player.giocatore_movimento[player.conta], player.posX, player.posY, 0);
        if (player.gravity == false && player.conta < MOV - 1)
        {

            player.posY -= calcolo; // alza il personaggio verso l'alto
            player.conta++; // cambia immagine, dando l'effetto della rotazione
        }
        if (player.gravity == true && player.conta > 2)
        {

            player.conta--; // Cambia immagine
            player.posY += 3; // Il personaggio va verso il basso
        }
        D2(cout << "Fatto!" << endl);
    }

    else if (stato == fine)
    {

        al_draw_bitmap(player.giocatore_movimento[player.conta], player.posX, player.posY, 0);
    }

    else if (stato == pausa)
    {

        al_draw_bitmap(player.giocatore_movimento[player.conta], player.posX, player.posY, 0);
    }
}

void aggiorna_gioco(Sfondo& background, state& stato, personaggio& player, float calcolo,
    Tubi tubo[], int& primoTubo, int& tub_conta, int& punteggio, float& incrementoVelocita,
    bool& inc, ALLEGRO_FONT* scritta[], int& record)
{

    D2(cout << "Aggiornamento dello sfondo di gioco.....");
    AggiornaSfondo(background, stato); // Funzione che ricarica lo sfondo.
    D2(cout << "Fatto!" << endl);
    D2(cout << "Aggiornamento del giocatore.....");
    AggiornaPlayer(player, calcolo,
        stato); // Funzione che consente di aggiornare il movimento e la rotazione del personaggio.
    D2(cout << "Aggiornamento dei tubi.....");
    AggiornaTubi(tubo, player, stato, primoTubo, tub_conta, punteggio, incrementoVelocita,
        inc); // Funzione che permette di
    // aggiornare i tubi, il loro
    // movimento, nonché gestisce
    // le collisioni del personaggio
    // con essi.
    D2(cout << "Aggiornamento dello stato di gioco.....");
    AggiornaStato(background, scritta, punteggio, record, stato); // Funzione che aggiorna lo sfondo inserendo
    // immagini appropriate in base allo stato.
    D2(cout << "Fatto!" << endl);
}
