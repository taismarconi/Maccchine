 /**\file strutt_dati.h 
   *In questo file sono contenute tutte le variabili globali utilizzate nel gioco, nonché tutte le strutture dati e i tipi 
   *enumerati sfruttati.
 **/

/**Costante rappresentante i frame per secondo.
  *
  *Tale valore permette al gioco di muoversi e aggiornarsi a una certa velocità, consentendo fluidità e scambio di immagini 
  *notevole. La frequenza dei frame viene misurata in hearts e tale costante viene utilizzata nella determinazione della frequenza 
  *di gioco al momento dell'inizializzazione del timer; vedere la documentazione della funzione ::crea_timer per maggiori dettagli 
  *in merito.
  *
**/
const float FPS = 150.;

/**Costante che indica la larghezza dello schermo.
  *
  *Tale misura altro non è che i pixel occupati dal display di gioco in larghezza, fatto definito nell'inizializzazione del display,
  * vedere la documentazione della funzione ::crea_display per ulteriori dettagli in merito.
  *
**/
const int SCREEN_W = 1305;

/**Costante che indica l'altezza dello schermo.
  *
  *Tale misura altro non è che i pixel occupati dal display di gioco in altezza, fatto definito nell'inizializzazione del display,
  * vedere la documentazione della funzione ::crea_display per ulteriori dettagli in merito.
  *
**/
const int SCREEN_H = 720;

/**Costante contenente la dimensione del vettore di immagini del personaggio nello stato iniziale.
  *
  *Tale valore viene usato nel file aggiornamenti.cc per aggiornare continuamente l'immagine del personaggio dando l'illusione che 
  *esso si muova. Vedere la documentazione della funzione ::AggiornaPlayer per ulteriori dettagli in merito.
  *
**/
const int INIZIO=8;

/**Costante contenente la dimensione del vettore di immagini del personaggio mentre il gioco è in corso.
  *
  *Tale valore viene usato nel file aggiornamenti.cc per aggiornare continuamente l'immagine del personaggio consentendo così la 
  *rotazione del personaggio durante il salto e durante la discesa. 
  *Vedere la documentazione della funzione ::AggiornaPlayer per ulteriori dettagli in merito.
  *
**/
const int MOV=11;

/**Enumerato che indica lo stato di gioco.
  *
  *In base allo stato di gioco attuale verrà eseguita una linea di codice diversa, in quanto tutto il gioco è ricco di controlli 
  *sullo stato, in modo tale che ogni funzione chiamata esegua codice differente in base allo stato in cui ci si trova. Per esempio 
  * se il gioco è in pausa allora tutti i tasti tranne il pulsante invio saranno disabilitati, così come lo sarà la gravità e il 
  *movimento dei tubi, mentre se lo stato del gioco è in_corso allora i tubi saranno generati, la gravità sarà attiva e il giocatore
  * potrà saltare.
  *
**/
enum state {inizio, pausa, fine, in_corso};

/**Enumerato che indica i tasti abilitati della tastiera, ovvero quali è possibile premere durante il gioco**/
enum MYKEYS {KEY_UP, KEY_SPACE, KEY_ENTER};

/**Struttura che rappresenta lo sfondo e le immagini a esso associate.
  *Questa struct è il tipo di una variabile dichiarata nel ::main e inizializzata in ::Inizializza_sfondo nel file 
  *inizializzazioni.cc. Come si nota dal codice la struct ha a disposizione diverse immagini che sono sfruttate nelle diverse 
  *condizioni di gioco e di stato.
  *
**/
struct Sfondo {

	/**Immagine riferita al pavimento di gioco.**/
	ALLEGRO_BITMAP *pavimento;
	 
	/**Immagine riferita al tema principale.**/
	ALLEGRO_BITMAP *tema; 
	
	/**Immagine riferita al tema di inizio gioco, in cui sono spiegati velocemente i tasti per poter giocare.**/
	ALLEGRO_BITMAP *start; 
	
	 /**Immagine rappresentante il pulsante di pausa quando si preme invio durante il gioco.**/
	ALLEGRO_BITMAP *pause;
	
	/**Vettore di immagini rappresentanti il game over, vengono utilizzate per l'appunto in questo stato.**/
	ALLEGRO_BITMAP *game_over[3];
};

/**Struttura che rappresenta i tubi e le immagini a essi associate.
  *Questa struct è il tipo di una variabile dichiarata nel ::main e inizializzata in ::inizializza_tubi nel file 
  *inizializzazioni.cc. Come si nota dal codice la variabile ha a disposizione diversi dati che rappresentano le caratteristiche 
  *di una certa coppia di tubi.
  *
**/
struct Tubi {
/**Variabile che indica la velocità di movimento dei tubi. Ogni volta che un tubo esce dallo schermo, questo viene reimpostato con
  * velocità sempre maggiore, per aumentare la difficoltà.
**/
	float velocity;
/**Variabile float che indica la posizione in orizzontale della coppia di tubi, la posizione X è la stessa per entrambi i tubi**/
	float posX1;
/**Variabile float che indica la posizione verticale del tubo più in basso**/
	float posY1;
/**Variabile float che indica la posizione verticale del tubo più in alto**/
	float posY2;
/**Variabile intera che indica l'altezza del tubo in basso, in modo tale da poterne gestire la collisione**/
	int maxCollisione1;
/**Variabile intera che indica l'altezza del tubo in alto, in modo tale da poterne gestire la collisione**/
	int maxCollisione2;
/**Vettore di due immagini, contenente il tubo che parte dal terreno e il tubo più in alto**/
	ALLEGRO_BITMAP *tubi2 [2];
/**variabile booleana che indica se un certo tubo è fuori dallo schermo o meno**/
	bool fuori_schermo;
};

/**Struttura che rappresenta il personaggio e le immagini a esso associate.
  *Questa struct è il tipo di una variabile dichiarata nel ::main e inizializzata in ::inizializza_giocatore nel file 
  *inizializzazioni.cc. Come si nota dal codice la variabile ha a disposizione diversi dati che rappresentano le caratteristiche 
  *del player.
  *
**/
struct personaggio {
/**Indica l'altezza complessiva del salto**/
	float velocity;
/**Posizione sull'asse delle ascisse del personaggio, resta sempre la medesima, sono i tubi che si muovono**/
	float posX;
/**Posizione sull'asse delle ordinate del personaggio**/
	float posY;
/**Vettore di immagini contenente le diverse pose del giocatore nel momento in cui il gioco è allo stato iniziale**/
	ALLEGRO_BITMAP *giocatore_inizio[INIZIO];
/**Vettore di immagini contenente i diversi gradi di rotazione del giocatore, utilizzato quando il gioco è in corso**/
	ALLEGRO_BITMAP *giocatore_movimento[MOV];
/**Variabile di appoggio utilizzata per vedere in quale posizione del vettore di bitmap usato ci si trova**/
	int conta=0;
/**Booleano che indica la gravità che agisce sul giocatore, impostata a false quando salta e a true quando cade**/
	bool gravity=false;
};
